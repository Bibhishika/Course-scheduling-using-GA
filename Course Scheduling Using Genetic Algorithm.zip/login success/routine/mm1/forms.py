from django.forms import ModelForm
from. models import *
from django import forms


# class RoomForm(ModelForm):
#     class Meta:
#         model = Room
#         fields = [
#             'r_number',
#             'seating_capacity'
#         ]

class LoginForm(forms.Form):
     username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={
            'placeholder': 'Username',
            'class': 'input-box'
        })
     )
     password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'placeholder': 'Password',
            'class': 'input-box'
        })
     )

class InstructorForm(ModelForm):
    class Meta:
        model = Instructor
        fields = [
            'uid',
            'name'
        ]


class MeetingTimeForm(ModelForm):
    class Meta:
        model = MeetingTime
        fields = [
            
            'time',
            'day'
        ]
        widgets = {
            
            'time': forms.Select(attrs={'class': 'custom-dropdown'}),
            'day': forms.Select(attrs={'class': 'custom-dropdown'}),
        }


class ComputerCourseForm(ModelForm):
    class Meta:
        model = ComputerCourse
        fields = ['course_number', 'course_name', 'credit_hours', 'instructors']


class ComputerSemesterForm(ModelForm):
    class Meta:
        model = ComputerSemester
        fields = ['semester', 'courses']
    
        
class ElectronicsSemesterForm(ModelForm):
    class Meta:
        model = ElectronicsSemester
        fields = ['semester', 'courses']
        

class ElectronicsCourseForm(ModelForm):
    class Meta:
        model = ElectronicsCourse
        fields = ['course_number', 'course_name', 'credit_hours', 'instructors']



class SelectsemesterForm(forms.ModelForm):
    class Meta:
        model = Selectsemester
        fields = [ 'computersemester','electronicssemester']
        widgets={
            'computersemester':forms.Select(attrs={'class': 'custom-dropdown'}),
            'electronicssemester':forms.Select(attrs={'class': 'custom-dropdown'})
            
            }
        
class FixedClassComputerForm(ModelForm):
    class Meta:
        model=FixedClassComputer
        fields=['semester','course', 'meeting_time','instructor']
        widgets={
             'semester':forms.Select(attrs={'class': 'custom-dropdown'}),
             'course':forms.Select(attrs={'class': 'custom-dropdown'}),
             'meeting_time':forms.Select(attrs={'class': 'custom-dropdown'}),
             'instructor':forms.Select(attrs={'class': 'custom-dropdown'}),
            }
        
class FixedClassElectronicsForm(ModelForm):
    class Meta:
        model=FixedClassElectronics
        fields=['semester','course', 'meeting_time','instructor']
        widgets={
             'semester':forms.Select(attrs={'class': 'custom-dropdown'}),
             'course':forms.Select(attrs={'class': 'custom-dropdown'}),
             'meeting_time':forms.Select(attrs={'class': 'custom-dropdown'}),
             'instructor':forms.Select(attrs={'class': 'custom-dropdown'}),
            }


